import tkinter as tk
from tkinter import END,messagebox
root=tk.Tk()
root.title("Calculadora")
root.config(width=300,height=500)
aux=0
signo=""

def operador(x):
    global signo,aux
    signo=x
    aux=float(txtDisplay.get())
    txtDisplay.delete(0,END)

def operacion():
    resultado=0
    aux2 = 0
    res_aux = 0
    global signo,aux
    if signo=="+":
        resultado=aux+float(txtDisplay.get())
    elif signo=="-":
        resultado=aux-float(txtDisplay.get())
    elif signo=="*":
        resultado=aux*float(txtDisplay.get()) # Agregar el caso de la multiplicación
    elif signo=="/":
        resultado=aux/float(txtDisplay.get()) # Agregar el caso de la división
    elif signo=="^":
        resultado=aux**float(txtDisplay.get())
    elif signo=="%":
        resultado=aux%float(txtDisplay.get())
    elif signo=="n!":
        resultado = 1
        for i in range(1, int(aux)+1):
            resultado *= i
        float(resultado)
    elif signo=="sqrt":
            numero = aux
            resultado = numero ** 0.5
    elif signo=="BIN":
        aux2 = int(aux)
        binario_str = str(aux2)
        resultado = int(binario_str, 2)
    elif signo=="OCT":
        octal = int(aux)
        octal_str = str(octal)
        resultado = 0
        for i, digito in enumerate(octal_str[::-1]):
            resultado += int(digito) * 8 ** i
    elif signo=="HEX":
        aux2 = int(aux)
        binario_str = str(aux2)
        resultado = int(binario_str, 16)
      
    else :
        resultado=aux+float(txtDisplay.get())
    txtDisplay.delete(0,END)
    txtDisplay.insert(0,str(resultado))
    txtDec.delete(0,END)
    txtDec.insert(0,str(resultado))
    #Octal-Dec
    res_aux = int(resultado)
    decimal = res_aux
    octal = ''

    while decimal > 0:
        residuo = decimal % 8
        octal = str(residuo) + octal
        decimal = decimal // 8

    txtOct.delete(0,END)
    txtOct.insert(0,str(octal))
    #Hex-Dec
    decimal = res_aux
    hexadecimal = ''

    while decimal > 0:
        residuo = decimal % 16
        if residuo < 10:
            hexadecimal = str(residuo) + hexadecimal
        else:
            hexadecimal = chr(ord('A') + residuo - 10) + hexadecimal
        decimal = decimal // 16

    txtHex.delete(0,END)
    txtHex.insert(0,str(hexadecimal))
    
    #BIN-DEC
    decimal = res_aux
    binario = ""

    while decimal > 0:
        residuo = decimal % 2
        binario = str(residuo) + binario
        decimal = decimal // 2
    txtBin.delete(0,END)
    txtBin.insert(0,str(binario))

    
    

#Crear numeros en pantalla
numeros = [0,1,2,3,4,5,6,7,8,9]
for i in numeros:
    btnNumero = tk.Button(root, text=str(i), command=lambda x=i: txtDisplay.insert(END, str(x)))
    btnNumero.place(x=10 + i*25, y=150)

# Crear el Entry y los Labels fuera de la función operacion
txtDisplay=tk.Entry(root)
txtDisplay.place(x=10,y=20)
txtDec=tk.Entry(root)
txtDec.place(x=45,y=40)
txtOct=tk.Entry(root)
txtOct.place(x=45,y=60)
txtHex=tk.Entry(root)
txtHex.place(x=45,y=80)
txtBin=tk.Entry(root)
txtBin.place(x=45,y=100)
tk.Label(root,text="DEC:").place(x=10,y=40)
tk.Label(root,text="OCT:").place(x=10,y=60)
tk.Label(root,text="HEX:").place(x=10,y=80)
tk.Label(root,text="BIN:").place(x=10,y=100)

# Usar lambda para crear funciones anónimas que llamen a operador y operacion con los argumentos adecuados
btnSuma=tk.Button(root,text="+", command=lambda: operador("+"))
btnSuma.place(x=10,y=200)
btnIgual=tk.Button(root,text="-", command=lambda: operador("-"))
btnIgual.place(x=30,y=200)
btnIgual=tk.Button(root,text="*", command=lambda: operador("*"))
btnIgual.place(x=50,y=200)
btnIgual=tk.Button(root,text="/", command=lambda: operador("/"))
btnIgual.place(x=70,y=200)
btnIgual=tk.Button(root,text="^", command=lambda: operador("^"))
btnIgual.place(x=90,y=200)
btnIgual=tk.Button(root,text="%", command=lambda: operador("%"))
btnIgual.place(x=110,y=200)
btnIgual=tk.Button(root,text="n!", command=lambda: operador("n!"))
btnIgual.place(x=130,y=200)
btnIgual=tk.Button(root,text="sqrt", command=lambda: operador("sqrt"))
btnIgual.place(x=150,y=200)
btnIgual=tk.Button(root,text="BIN-DEC", command=lambda: operador("BIN"))
btnIgual.place(x=10,y=250)
btnIgual=tk.Button(root,text="OCT-DEC", command=lambda: operador("OCT"))
btnIgual.place(x=100,y=250)
btnIgual=tk.Button(root,text="HEX-DEC", command=lambda: operador("HEX"))
btnIgual.place(x=10,y=300)
btnIgual=tk.Button(root,text="=", command=lambda: operacion())
btnIgual.place(x=200,y=200)
root.mainloop()

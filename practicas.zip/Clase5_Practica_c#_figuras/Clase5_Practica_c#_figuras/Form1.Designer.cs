﻿namespace Clase5_Practica_c__figuras
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_calcular = new System.Windows.Forms.Button();
            this.lb_base = new System.Windows.Forms.Label();
            this.lb_altura = new System.Windows.Forms.Label();
            this.lb_area = new System.Windows.Forms.Label();
            this.tx_base = new System.Windows.Forms.TextBox();
            this.tx_altura = new System.Windows.Forms.TextBox();
            this.tx_area = new System.Windows.Forms.TextBox();
            this.cb_opcion = new System.Windows.Forms.ComboBox();
            this.lb_opcion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_calcular
            // 
            this.bt_calcular.Location = new System.Drawing.Point(677, 150);
            this.bt_calcular.Name = "bt_calcular";
            this.bt_calcular.Size = new System.Drawing.Size(112, 48);
            this.bt_calcular.TabIndex = 0;
            this.bt_calcular.Text = "Calcular area";
            this.bt_calcular.UseVisualStyleBackColor = true;
            this.bt_calcular.Click += new System.EventHandler(this.bt_calcular_Click);
            // 
            // lb_base
            // 
            this.lb_base.AutoSize = true;
            this.lb_base.Location = new System.Drawing.Point(166, 70);
            this.lb_base.Name = "lb_base";
            this.lb_base.Size = new System.Drawing.Size(39, 16);
            this.lb_base.TabIndex = 1;
            this.lb_base.Text = "Base";
            // 
            // lb_altura
            // 
            this.lb_altura.AutoSize = true;
            this.lb_altura.Location = new System.Drawing.Point(166, 113);
            this.lb_altura.Name = "lb_altura";
            this.lb_altura.Size = new System.Drawing.Size(41, 16);
            this.lb_altura.TabIndex = 2;
            this.lb_altura.Text = "Altura";
            // 
            // lb_area
            // 
            this.lb_area.AutoSize = true;
            this.lb_area.Location = new System.Drawing.Point(166, 166);
            this.lb_area.Name = "lb_area";
            this.lb_area.Size = new System.Drawing.Size(36, 16);
            this.lb_area.TabIndex = 3;
            this.lb_area.Text = "Area";
            // 
            // tx_base
            // 
            this.tx_base.Location = new System.Drawing.Point(235, 70);
            this.tx_base.Name = "tx_base";
            this.tx_base.Size = new System.Drawing.Size(174, 22);
            this.tx_base.TabIndex = 4;
            // 
            // tx_altura
            // 
            this.tx_altura.Location = new System.Drawing.Point(235, 113);
            this.tx_altura.Name = "tx_altura";
            this.tx_altura.Size = new System.Drawing.Size(174, 22);
            this.tx_altura.TabIndex = 5;
            // 
            // tx_area
            // 
            this.tx_area.Location = new System.Drawing.Point(235, 166);
            this.tx_area.Name = "tx_area";
            this.tx_area.Size = new System.Drawing.Size(174, 22);
            this.tx_area.TabIndex = 6;
            // 
            // cb_opcion
            // 
            this.cb_opcion.FormattingEnabled = true;
            this.cb_opcion.Items.AddRange(new object[] {
            "Triangulo",
            "Cuadrado",
            "Rectangulo",
            "Poligono"});
            this.cb_opcion.Location = new System.Drawing.Point(529, 105);
            this.cb_opcion.Name = "cb_opcion";
            this.cb_opcion.Size = new System.Drawing.Size(260, 24);
            this.cb_opcion.TabIndex = 7;
            // 
            // lb_opcion
            // 
            this.lb_opcion.AutoSize = true;
            this.lb_opcion.Location = new System.Drawing.Point(526, 75);
            this.lb_opcion.Name = "lb_opcion";
            this.lb_opcion.Size = new System.Drawing.Size(144, 16);
            this.lb_opcion.TabIndex = 8;
            this.lb_opcion.Text = "Seleccione una opcion";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(941, 300);
            this.Controls.Add(this.lb_opcion);
            this.Controls.Add(this.cb_opcion);
            this.Controls.Add(this.tx_area);
            this.Controls.Add(this.tx_altura);
            this.Controls.Add(this.tx_base);
            this.Controls.Add(this.lb_area);
            this.Controls.Add(this.lb_altura);
            this.Controls.Add(this.lb_base);
            this.Controls.Add(this.bt_calcular);
            this.Name = "Form1";
            this.Text = "Calculo de Areas";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_calcular;
        private System.Windows.Forms.Label lb_base;
        private System.Windows.Forms.Label lb_altura;
        private System.Windows.Forms.Label lb_area;
        private System.Windows.Forms.TextBox tx_base;
        private System.Windows.Forms.TextBox tx_altura;
        private System.Windows.Forms.TextBox tx_area;
        private System.Windows.Forms.ComboBox cb_opcion;
        private System.Windows.Forms.Label lb_opcion;
    }
}


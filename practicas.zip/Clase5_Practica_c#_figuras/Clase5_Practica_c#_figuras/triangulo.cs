﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase5_Practica_c__figuras
{
    internal class triangulo
    {
        private double base_;
        private double altura_;
        private double area_;

        //public double Base_ { get => base_; set => base_ = value; }
        //public double Altura_ { get => altura_; set => altura_ = value; }
        //public double Area_ { get => area_; set => area_ = value; }
        public void setbase(double base_)
        {
            this.base_ = base_;
        }
        public double getbase()
        {
            return this.base_;
        }
        public void setaltura(double altura_)
        {
            this.altura_ = altura_;
        }
        public double getaltura()
        {
            return this.altura_;
        }
        public void calcular_area()
        {
            this.area_ = (this.base_*this.altura_)/2;
        }
        public double getarea()
        {
            return this.area_;
        }
    }
}

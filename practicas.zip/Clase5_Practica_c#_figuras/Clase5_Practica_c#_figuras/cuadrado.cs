﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase5_Practica_c__figuras
{
    internal class cuadrado
    {
        private double lado_;
        private double area_;

        //public double Base_ { get => base_; set => base_ = value; }
        //public double Altura_ { get => altura_; set => altura_ = value; }
        //public double Area_ { get => area_; set => area_ = value; }
        public void setlado(double lado_)
        {
            this.lado_ = lado_;
        }
        public double getlado()
        {
            return this.lado_;
        }
        public void calcular_area()
        {
            this.area_ = (this.lado_ * this.lado_);
        }
        public double getarea()
        {
            return this.area_;
        }
    }
}

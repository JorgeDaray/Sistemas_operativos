﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase5_Practica_c__figuras
{
    public partial class Form1 : Form
    {
        triangulo t;
        cuadrado c;
        rectangulo r;
        poligono p;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bt_calcular_Click(object sender, EventArgs e)
        {
            if(cb_opcion.SelectedItem.ToString().Equals("Triangulo")) 
            {
                t = new triangulo();
                t.setbase(double.Parse(tx_base.Text));
                t.setaltura(double.Parse(tx_altura.Text));
                t.calcular_area();
                tx_area.Text = t.getarea().ToString();
            }
            if (cb_opcion.SelectedItem.ToString().Equals("Cuadrado"))
            {
                c = new cuadrado();
                c.setlado(double.Parse(tx_base.Text));
                c.calcular_area();
                tx_area.Text = c.getarea().ToString();
            }
            if (cb_opcion.SelectedItem.ToString().Equals("Rectangulo"))
            {
                r = new rectangulo();
                r.setbase(double.Parse(tx_base.Text));
                r.setaltura(double.Parse(tx_altura.Text));
                r.calcular_area();
                tx_area.Text = r.getarea().ToString();
            }
            if (cb_opcion.SelectedItem.ToString().Equals("Poligono"))
            {
                p = new poligono();
                p.setlados(double.Parse(tx_base.Text));
                p.setlado(double.Parse(tx_altura.Text));
                p.calcular_area();
                tx_area.Text = p.getarea().ToString();
            }
        }
    }
}

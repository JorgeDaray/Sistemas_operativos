﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase5_Practica_c__figuras
{
    internal class poligono
    {
        private double lados_;
        private double lado_;
        private double area_;

        //public double Base_ { get => base_; set => base_ = value; }
        //public double Altura_ { get => altura_; set => altura_ = value; }
        //public double Area_ { get => area_; set => area_ = value; }
        public void setlados(double lados_)
        {
            this.lados_ = lados_;
        }
        public double getlados()
        {
            return this.lados_;
        }
        public void setlado(double lado_)
        {
            this.lado_ = lado_;
        }
        public double getlado()
        {
            return this.lado_;
        }
        public void calcular_area()
        {
            this.area_ = (this.lados_ * this.lado_ * 4)/2;
        }
        public double getarea()
        {
            return this.area_;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Xml.Schema;

namespace Clase6_histograma
{
    public partial class Form1 : Form
    {
        int[] conjunto = { 5, 8, 9, 7, 4, 2, 1, 3, 6 };
        String[] datos = { "A", "B", "C", "D", "E", "F", "G", "H", "I" };
        Burbuja b;
        public Form1()
        {
            InitializeComponent();
            b = new Burbuja(conjunto);
        }

        private void Ordenar_Click(object sender, EventArgs e)
        {
            b.Ordenar();
            conjunto = b.getConjunto();

            Series series = this.chart1.Series.Add("Total ");
            this.chart1.Series.Clear();

            this.chart1.Palette = ChartColorPalette.SeaGreen;
            this.chart1.Titles.Add("Ventas");
            for (int i = 0; i < conjunto.Length; i++)
            {
                series = this.chart1.Series.Add(datos[i]);
                series.Points.Add(conjunto[i]);
            }

        }
    }
}

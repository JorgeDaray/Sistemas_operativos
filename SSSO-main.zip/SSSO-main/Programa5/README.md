Programa 5 "QUANTUM" de la materia de seminario de solucion de problemas de sistemas operativos, la llevé con Julio Esteban Valdes Lopez, pero son las mismas actividades que Violeta

Programa seis "PRODUCTOR - CONSUMIDOR" de la materia de seminario de solucion de problemas de sistemas operativos.
En este caso el productor es un bloque "?" de Super Mario Bros, y el consumidor es el propio Mario. El bloque produce diferentes items y Mario se transforma según el item que consume. Esto implica el uso de bastantes archivos.png, por lo que el proyecto es pesado.

NOTA: me equivoqué al ponerle nombre al proyecto, y le puse "Practica6". Lo cambié aquí en Git para que no se vea desordenado. Probabelemente sea necesario ponerle "Practica6" al proyecto al momento de descargarlo y ejecutarlo, pues si no se hace pueden saltar errores.

# SSSO
Seminario de Solución de Problemas de Sistemas Operativos. 

Profesor: Julio Esteban Lopez Valdes. 

Sección: D08. 

CUCEI. 


Estos son los 7 programas de la materia, para leer las teclas del teclado, se hace con un cuadro de texto invisible, solo se leen de forma normal cuando no está activo el temporizador. No me siento orgulloso.
Las prácticas son las mismas que deja Violeta.

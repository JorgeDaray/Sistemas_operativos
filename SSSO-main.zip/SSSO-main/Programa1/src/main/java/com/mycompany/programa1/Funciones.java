package com.mycompany.programa1;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author carlossalcidoa
 */
public class Funciones {
    
    //ArrayList <>
    
    //Proceso listaProcesos[];
    
    //public class Proceso(listaProcesos[] recibir){
    //    this.listaProcesos;
    //}
    
    public void insertarInfo(String nombre, int num1, String operacion, int num2, String id, int tiempo, int cont){
        
        
/*
        
        listaProcesos[10] = new Proceso("nombre", 1, "operacion", 2, "id", 0);
        listaProcesos[cont] = new Proceso(nombre, num1, operacion, num2, id, tiempo);
        JOptionPane.showMessageDialog(null, "AAAAAAAAABC");
        System.out.println("owoowowow");
        System.out.println(listaProcesos[10].ImprimirNombre());
        System.out.println(listaProcesos[cont].ImprimirNombre());
        System.out.println("owoowowow");*/
    }
    
    //public DefaultTableModel LoteTrabajando(){
    /*
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Nombre");
        model.addColumn("Tiempo");
        Object[] ob = new Object[2];
        //ob[0]= "aa";
        //ob[1]= "bbb";
        ob[0]= listaProcesos[10].ImprimirNombre();
        ob[1]= listaProcesos[10].ImprimirTiempo();
        //System.out.println(listaProcesos[10].ImprimirNombre());

        //String variable1 = listaProcesos[0].ImprimirNombre();
        //String variable2 = Integer.toString(listaProcesos[0].ImprimirTiempo());
        //System.out.println(variable1);
        //System.out.println(variable2);
        
        model.addRow(ob);
        
        return model;*/
   // }
    
    
    
}

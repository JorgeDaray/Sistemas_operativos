Programa siete y último "PAGINACION SIMPLE" de la materia de seminario de solucion de problemas de sistemas operativos.

NOTA: No funciona al 100%, la diferencia con el programa 5 es que se crea y se muestra con 'm' la tabla de paginacion de forma efectiva, pero no se actualiza mientras se agregan procesos, se bloquean procesos, o se finalizan procesos. Saqué 90/100 debido a que utilicé fracciones para mostrar la memoria de los procesos, en lugar de colores, como en el ejemplo.
